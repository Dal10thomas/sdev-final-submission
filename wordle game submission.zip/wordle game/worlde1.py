#Dalton Abbott
#sdev140 final
#written from 2/16 - 3/7
#this progrsm recreates the popular game wordle in tkinter

#importing all data neede for main game to work
import enum
from tkinter import *
from tkinter import messagebox
import words #this is the program that sorts words to find ones with 5 letters and selects on at random
import random
root = Tk()
word = words.get_word() #worlde backbone of random word
root.geometry('400x400') #size of window
#colors for background
GREEN = "#20d450" 
YELLOW = "#faf614"
BLACK = "#000000"
WHITE = "#FFFFFF"
GREY = "#8f8f8b"

def color(): #color button
    # Generating a random number in between 0 and 2^24
    color = random.randrange(0, 2**24)
 
    # Converting that number from base-10 (decimal) to base-16 (hexadecimal)
    hex_color = hex(color)
 
    std_color = "#" + hex_color[2:]
    root.config(bg = std_color) 
    #this makes the color button set background to random hexadecimal

root.config(bg = BLACK)
#until color is activated background is black
guessnum = 1#guess counter
#textbox
wordInput = Entry(root)
wordInput.grid(row=999, column=1, padx=10, pady=10, columnspan=3)


def close():#exit button
    root.destroy()

def getGuess():#guess button

    global word
    guess = wordInput.get()

    global guessnum#guess counter
    guessnum += 1

    if guessnum <= 5:  #guess limit

        if len(guess) == 5:

            if word == guess: #CORRECT
                messagebox.showinfo("correct!", f"correct! the word was {word.title()}")
            else:             #INCORRECT
                for i, letter in enumerate(guess):

                    label = Label(root, text=letter.upper())
                    label.grid(row=guessnum, column=i, padx=10, pady=10) #this puts the the guess number equal to the row so every guess goes to the bottom

                    if letter == word[i]: #if they get the letter right
                        label.config(bg=GREEN, fg=BLACK)

                    if letter in word and not letter == word[i]: #not in the correct spot
                        label.config(bg=YELLOW, fg=BLACK)
                    
                    if letter not in word:#not in the word
                        label.config(bg=GREY, fg=BLACK)

        else:
            messagebox.showerror("must be 5 letters", " use 5 letters in your guess")
            guessnum = guessnum -1#this prevents the incorect guess type counting tward your five guesses
    
    else:
        messagebox.showerror("you lose!", f"You Lose! The word was {word}")#L bozo 



wordGuessButton = Button(root, text="Guess", command=getGuess)
wordGuessButton.grid(row=999, column=4, columnspan=2)#Guess button

colorButton = Button(root, text="Color", command=color)
colorButton.grid(row=999, column=6, columnspan=2)#color button

exit_button = Button(root, text="Exit", command=close)
exit_button.grid(row=999, column=8, columnspan=2)#exit button
root.mainloop()
